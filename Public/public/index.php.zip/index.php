<?php
// Página inicial do Observatório Mulheres na Computação e Inovação.
// Este arquivo serve a interface moderna com dashboard interativo.
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Observatório Mulheres na Computação</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Biblioteca Chart.js para gráficos -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<header>
    <div class="header-content">
        <img src="img/logo.png" alt="Logo Observatório" class="logo">
        <div class="title-box">
            <h1>Mulheres na Computação e Inovação</h1>
            <p>Observatório Global de Líderes em Tecnologia</p>
        </div>
    </div>
</header>
<!-- Imagem de capa -->
<section class="hero">
    <img src="img/MulheresCapa.png" alt="Capa Mulheres na Computação" class="capa">
</section>
<main>
    <!-- Estatísticas resumo -->
    <section class="stats">
        <div class="stat-card">
            <h3 id="total-perfis">0</h3>
            <p>Mulheres</p>
        </div>
        <div class="stat-card">
            <h3 id="total-areas">0</h3>
            <p>Áreas de atuação</p>
        </div>
        <div class="stat-card">
            <h3 id="total-paises">0</h3>
            <p>Países</p>
        </div>
        <div class="stat-card">
            <h3 id="total-continentes">0</h3>
            <p>Continentes</p>
        </div>
    </section>

    <!-- Campo de busca -->
    <section class="busca">
        <input type="text" id="search-input" placeholder="Buscar perfis (nome ou termo)">
        <button id="btn-search">Pesquisar</button>
    </section>

    <!-- Gráfico de distribuição -->
    <section class="chart-container">
        <canvas id="chartDistribuicao"></canvas>
    </section>

    <!-- Filtros de continente -->
    <section class="continentes">
        <div class="continente-card filtro-continente" data-continente="America">América</div>
        <div class="continente-card filtro-continente" data-continente="Europa">Europa</div>
        <div class="continente-card filtro-continente" data-continente="Africa">África</div>
        <div class="continente-card filtro-continente" data-continente="Asia">Ásia</div>
        <div class="continente-card filtro-continente" data-continente="Oceania">Oceania</div>
    </section>

    <!-- Lista de perfis -->
    <section id="lista-perfis" data-page="1"></section>
    <button id="btn-load-more">Carregar mais</button>
    
</main>
<script src="js/main.js"></script>
</body>
</html>